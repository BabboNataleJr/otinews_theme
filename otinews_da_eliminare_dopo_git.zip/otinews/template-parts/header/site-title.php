<div class="row">
    <div class="col-md-4 align-self-center">
        <a href="/" class="navbar-brand" id="navbar-brand-name">
            <img src="<?php header_image();?>" alt="logo">
        </a>
    </div>
    <div class="col-md-8 align-self-end">
        <?php get_template_part('template-parts/header/director', 'name'); ?>
    </div>
</div>