    inNews è una testata giornalistica in corso di registrazione<br />
    <a href="/" class="navbar-brand" id="navbar-brand-name">
        Direttore responsabile Andrea Settefonti
    </a>