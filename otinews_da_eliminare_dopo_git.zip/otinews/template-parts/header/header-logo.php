<div class="row">
    <!-- Brand's Logo -->
    <div class="col-md-1"></div>
    <div class="brand-icon col-md-2">
        <?php get_template_part('template-parts/header/brand', 'logo'); ?>
    </div>
    <div class="col-md-1"></div>
    <!-- Name of the WebSite -->
    <div class="navbar-header col-md-8 align-self-center">
        <?php get_template_part('template-parts/header/site', 'title'); ?>
    </div>
    <!-- Responsabile Director of the WebSite -->
    <!-- <div class="navbar-header col-md-3 align-self-center">
        <div> -->

    <!-- </div>
    </div> -->
</div>